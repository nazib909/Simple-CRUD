from django import forms
from django.contrib.auth.models import User


# class userForm(forms.Form):
#     name = forms.CharField()
#     password = forms.IntegerField(widget=forms.PasswordInput)