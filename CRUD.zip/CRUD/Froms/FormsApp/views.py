from django.shortcuts import render, redirect
from .models import profile


def login(r):
    if r.method == 'POST':
        name = r.POST['name']
        email = r.POST['email']
        img = r.FILES['fileupload']
        user = profile.objects.create(name=name, email=email, proPic=img)
        user.save()

    return render(r, 'login.html', locals())


def Prof(r):
    pro = profile.objects.all()
    print(pro[0].proPic.path)
    return render(r, 'newProf.html', locals())


def update(r, id):
    pro = profile.objects.filter(id = id).all()
    pro = pro[0]
    if r.method == 'POST':
        name = r.POST['name']
        email = r.POST['email']
        img = r.FILES['fileupload']
        pro.proPic=img
        pro.name = name
        pro.email = email
        pro.save()

    return render(r, 'Update.html', locals())


def delete(r, id):
    p = profile.objects.get(id=id)
    p.delete()
    return redirect("Prof")
